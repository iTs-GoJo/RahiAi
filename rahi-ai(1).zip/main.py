# main.py

from chatbot.core import check_creator_question

def main():
    print("🤖 RahiAI آماده‌ست! برای خروج 'exit' رو بزن.")
    while True:
        user_input = input("👤 شما: ").strip()
        if user_input.lower() in ["exit", "خروج"]:
            print("👋 خدافظ!")
            break

        response = check_creator_question(user_input)
        if response:
            print("🤖 RahiAI:", response)
        else:
            print("🤖 RahiAI: (اینجا مدل LLM وصل میشه...)")

if __name__ == "__main__":
    main()
