from flask import Flask, render_template, request, jsonify
from chatbot.core import check_creator_question

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    data = request.json
    user_input = data.get("message", "")

    response = check_creator_question(user_input)
    if not response:
        response = "🤖 RahiAI: (اینجا بعداً مدل LLM جواب می‌ده...)"

    return jsonify({"response": response})

if __name__ == "__main__":
    app.run(debug=True)
