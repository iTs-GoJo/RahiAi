# utils/prompt_builder.py

def build_prompt(history, user_input, personality):
    return f"{personality}\nUser: {user_input}\nAI:"
