# chatbot/config.py

CREATOR_NAME = "Ali Jafari"

KEYWORDS_CREATOR = [
    "سازنده",
    "کی تو رو ساخته",
    "ساخته کی هستی",
    "برنامه‌نویس تو کیه",
    "نویسنده تو کیه"
]
