# chatbot/core.py

from chatbot.config import CREATOR_NAME, KEYWORDS_CREATOR

def check_creator_question(user_input: str) -> str | None:
    for kw in KEYWORDS_CREATOR:
        if kw in user_input:
            return f"سازنده من {CREATOR_NAME} هست. اون مغز متفکر پشت منه! 😎"
    return None
